const form = document.getElementById("contactForm");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const messageInput = document.getElementById("message");

const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;

function setError(input, errorId, text) {
    document.getElementById(errorId).textContent = text;
    input.classList.toggle("invalid", text !== "");
    return text === "";
}

function validateName() {
    const empty = nameInput.value.trim() === "";
    return setError(nameInput, "nameError", empty ? "Name cannot be empty." : "");
}

function validateEmail() {
    const v = emailInput.value.trim();
    let msg = "";
    if (v === "") msg = "Email cannot be empty.";
    else if (!emailPattern.test(v)) msg = "Please enter a valid email address.";
    return setError(emailInput, "emailError", msg);
}

function validateMessage() {
    const empty = messageInput.value.trim() === "";
    return setError(messageInput, "messageError", empty ? "Message cannot be empty." : "");
}

form.addEventListener("submit", function (e) {
    e.preventDefault();
    const ok = [validateName(), validateEmail(), validateMessage()].every(Boolean);
    if (ok) {
        const subject = encodeURIComponent("Portfolio message from " + nameInput.value.trim());
        const body = encodeURIComponent(messageInput.value.trim() + "\n\nFrom: " + nameInput.value.trim() + " (" + emailInput.value.trim() + ")");
        window.location.href = "mailto:yshsingh24@gmail.com?subject=" + subject + "&body=" + body;
        form.reset();
    }
});